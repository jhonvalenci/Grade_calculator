﻿
namespace Grade_calculator
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbNamestudent = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbCredicurso = new System.Windows.Forms.Label();
            this.lbCcurso = new System.Windows.Forms.Label();
            this.lbCprograma = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.cBNcurso = new System.Windows.Forms.ComboBox();
            this.cBPrograma = new System.Windows.Forms.ComboBox();
            this.tBCorreo = new System.Windows.Forms.TextBox();
            this.tBFijo = new System.Windows.Forms.TextBox();
            this.tBCelular = new System.Windows.Forms.TextBox();
            this.tBapellido = new System.Windows.Forms.TextBox();
            this.tBnombre = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grpNotas = new System.Windows.Forms.GroupBox();
            this.btLimpiar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btCalcular = new System.Windows.Forms.Button();
            this.tBnota5 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tBnota4 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tBnota2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tBnota3 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tBnota1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.BtSalir = new System.Windows.Forms.Button();
            this.numerocel = new System.Windows.Forms.ErrorProvider(this.components);
            this.Numerofijo = new System.Windows.Forms.ErrorProvider(this.components);
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.grpNotas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numerocel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Numerofijo)).BeginInit();
            this.SuspendLayout();
            // 
            // lbNamestudent
            // 
            this.lbNamestudent.AutoSize = true;
            this.lbNamestudent.BackColor = System.Drawing.Color.Transparent;
            this.lbNamestudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNamestudent.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbNamestudent.Location = new System.Drawing.Point(43, 54);
            this.lbNamestudent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbNamestudent.Name = "lbNamestudent";
            this.lbNamestudent.Size = new System.Drawing.Size(66, 18);
            this.lbNamestudent.TabIndex = 0;
            this.lbNamestudent.Text = "Nombre:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.lbCredicurso);
            this.groupBox1.Controls.Add(this.lbCcurso);
            this.groupBox1.Controls.Add(this.lbCprograma);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.cBNcurso);
            this.groupBox1.Controls.Add(this.cBPrograma);
            this.groupBox1.Controls.Add(this.tBCorreo);
            this.groupBox1.Controls.Add(this.tBFijo);
            this.groupBox1.Controls.Add(this.tBCelular);
            this.groupBox1.Controls.Add(this.tBapellido);
            this.groupBox1.Controls.Add(this.tBnombre);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.lbNamestudent);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(37, 52);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(540, 459);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del estudiante";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lbCredicurso
            // 
            this.lbCredicurso.AutoSize = true;
            this.lbCredicurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCredicurso.Location = new System.Drawing.Point(277, 425);
            this.lbCredicurso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCredicurso.Name = "lbCredicurso";
            this.lbCredicurso.Size = new System.Drawing.Size(0, 18);
            this.lbCredicurso.TabIndex = 21;
            // 
            // lbCcurso
            // 
            this.lbCcurso.AutoSize = true;
            this.lbCcurso.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCcurso.Location = new System.Drawing.Point(281, 386);
            this.lbCcurso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCcurso.Name = "lbCcurso";
            this.lbCcurso.Size = new System.Drawing.Size(0, 18);
            this.lbCcurso.TabIndex = 20;
            // 
            // lbCprograma
            // 
            this.lbCprograma.AutoSize = true;
            this.lbCprograma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCprograma.Location = new System.Drawing.Point(277, 308);
            this.lbCprograma.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbCprograma.Name = "lbCprograma";
            this.lbCprograma.Size = new System.Drawing.Size(0, 18);
            this.lbCprograma.TabIndex = 19;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(273, 223);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(160, 18);
            this.label15.TabIndex = 18;
            this.label15.Text = "@pascualbravo.edu.co";
            // 
            // cBNcurso
            // 
            this.cBNcurso.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBNcurso.FormattingEnabled = true;
            this.cBNcurso.Items.AddRange(new object[] {
            "--SELECCIONE--",
            "SISTEMAS OPERATIVOS I",
            "INGENIERIA DE SOFTWARE II",
            "HERRAMIENTAS DE PROGRAMACION III",
            "MATEMÁTICAS ESPECIALES ",
            "INTELIGENCIA DE NEGOCIOS (BI)",
            "INGLÉS 4 "});
            this.cBNcurso.Location = new System.Drawing.Point(277, 347);
            this.cBNcurso.Margin = new System.Windows.Forms.Padding(4);
            this.cBNcurso.Name = "cBNcurso";
            this.cBNcurso.Size = new System.Drawing.Size(215, 24);
            this.cBNcurso.TabIndex = 17;
            this.cBNcurso.SelectedIndexChanged += new System.EventHandler(this.cBNcurso_SelectedIndexChanged);
            // 
            // cBPrograma
            // 
            this.cBPrograma.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cBPrograma.FormattingEnabled = true;
            this.cBPrograma.Items.AddRange(new object[] {
            "--SELECCIONE--",
            "Tecnologia en Sistemas",
            "Tecnologia Electronica",
            "Profesional en DIseño Grafico",
            "Ingenieria Mecanica ",
            "Ingenieria en Logistica",
            "Ingenieria De Software"});
            this.cBPrograma.Location = new System.Drawing.Point(277, 266);
            this.cBPrograma.Margin = new System.Windows.Forms.Padding(4);
            this.cBPrograma.Name = "cBPrograma";
            this.cBPrograma.Size = new System.Drawing.Size(215, 24);
            this.cBPrograma.TabIndex = 15;
            this.cBPrograma.SelectedIndexChanged += new System.EventHandler(this.cBPrograma_SelectedIndexChanged);
            // 
            // tBCorreo
            // 
            this.tBCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBCorreo.Location = new System.Drawing.Point(277, 193);
            this.tBCorreo.Margin = new System.Windows.Forms.Padding(4);
            this.tBCorreo.Name = "tBCorreo";
            this.tBCorreo.Size = new System.Drawing.Size(155, 24);
            this.tBCorreo.TabIndex = 14;
            this.tBCorreo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBCorreo_KeyPress);
            // 
            // tBFijo
            // 
            this.tBFijo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBFijo.Location = new System.Drawing.Point(277, 162);
            this.tBFijo.Margin = new System.Windows.Forms.Padding(4);
            this.tBFijo.MaxLength = 7;
            this.tBFijo.Name = "tBFijo";
            this.tBFijo.Size = new System.Drawing.Size(155, 24);
            this.tBFijo.TabIndex = 13;
            this.tBFijo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBFijo_KeyPress);
            // 
            // tBCelular
            // 
            this.tBCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBCelular.Location = new System.Drawing.Point(277, 126);
            this.tBCelular.Margin = new System.Windows.Forms.Padding(4);
            this.tBCelular.MaxLength = 10;
            this.tBCelular.Name = "tBCelular";
            this.tBCelular.Size = new System.Drawing.Size(155, 24);
            this.tBCelular.TabIndex = 12;
            this.tBCelular.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBCelular_KeyPress);
            // 
            // tBapellido
            // 
            this.tBapellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBapellido.Location = new System.Drawing.Point(277, 89);
            this.tBapellido.Margin = new System.Windows.Forms.Padding(4);
            this.tBapellido.Name = "tBapellido";
            this.tBapellido.Size = new System.Drawing.Size(155, 24);
            this.tBapellido.TabIndex = 11;
            this.tBapellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBapellido_KeyPress);
            // 
            // tBnombre
            // 
            this.tBnombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBnombre.Location = new System.Drawing.Point(277, 54);
            this.tBnombre.Margin = new System.Windows.Forms.Padding(4);
            this.tBnombre.Name = "tBnombre";
            this.tBnombre.Size = new System.Drawing.Size(155, 24);
            this.tBnombre.TabIndex = 10;
            this.tBnombre.TextChanged += new System.EventHandler(this.tBnombre_TextChanged);
            this.tBnombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBnombre_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(43, 423);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 18);
            this.label9.TabIndex = 9;
            this.label9.Text = "Creditos del curso:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(43, 386);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 18);
            this.label8.TabIndex = 8;
            this.label8.Text = "Codigo del curso:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(43, 347);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 18);
            this.label7.TabIndex = 7;
            this.label7.Text = "Nombre del curso:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(43, 308);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 18);
            this.label6.TabIndex = 6;
            this.label6.Text = "Codigo del programa:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(43, 197);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 18);
            this.label5.TabIndex = 5;
            this.label5.Text = "Correo electronico:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(43, 267);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(159, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Programa matriculado:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(43, 162);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Fijo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(43, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Celular:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(43, 89);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Apellido:";
            // 
            // grpNotas
            // 
            this.grpNotas.BackColor = System.Drawing.Color.Transparent;
            this.grpNotas.Controls.Add(this.btLimpiar);
            this.grpNotas.Controls.Add(this.pictureBox1);
            this.grpNotas.Controls.Add(this.btCalcular);
            this.grpNotas.Controls.Add(this.tBnota5);
            this.grpNotas.Controls.Add(this.label14);
            this.grpNotas.Controls.Add(this.tBnota4);
            this.grpNotas.Controls.Add(this.label13);
            this.grpNotas.Controls.Add(this.tBnota2);
            this.grpNotas.Controls.Add(this.label12);
            this.grpNotas.Controls.Add(this.tBnota3);
            this.grpNotas.Controls.Add(this.label11);
            this.grpNotas.Controls.Add(this.tBnota1);
            this.grpNotas.Controls.Add(this.label10);
            this.grpNotas.Enabled = false;
            this.grpNotas.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.grpNotas.Location = new System.Drawing.Point(585, 52);
            this.grpNotas.Margin = new System.Windows.Forms.Padding(4);
            this.grpNotas.Name = "grpNotas";
            this.grpNotas.Padding = new System.Windows.Forms.Padding(4);
            this.grpNotas.Size = new System.Drawing.Size(452, 459);
            this.grpNotas.TabIndex = 2;
            this.grpNotas.TabStop = false;
            this.grpNotas.Text = "Notas";
            // 
            // btLimpiar
            // 
            this.btLimpiar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btLimpiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLimpiar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btLimpiar.Location = new System.Drawing.Point(229, 150);
            this.btLimpiar.Margin = new System.Windows.Forms.Padding(4);
            this.btLimpiar.Name = "btLimpiar";
            this.btLimpiar.Size = new System.Drawing.Size(133, 31);
            this.btLimpiar.TabIndex = 23;
            this.btLimpiar.Text = "Limpiar";
            this.btLimpiar.UseVisualStyleBackColor = false;
            this.btLimpiar.Click += new System.EventHandler(this.btLimpiar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Grade_calculator.Properties.Resources.avatar_face_man_boy_profile_smiley_happy_people_icon_181659;
            this.pictureBox1.Location = new System.Drawing.Point(137, 223);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(181, 176);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // btCalcular
            // 
            this.btCalcular.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCalcular.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btCalcular.Location = new System.Drawing.Point(69, 150);
            this.btCalcular.Margin = new System.Windows.Forms.Padding(4);
            this.btCalcular.Name = "btCalcular";
            this.btCalcular.Size = new System.Drawing.Size(133, 31);
            this.btCalcular.TabIndex = 20;
            this.btCalcular.Text = "Calcular";
            this.btCalcular.UseVisualStyleBackColor = false;
            this.btCalcular.Click += new System.EventHandler(this.btCalcular_Click);
            // 
            // tBnota5
            // 
            this.tBnota5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBnota5.Location = new System.Drawing.Point(371, 66);
            this.tBnota5.Margin = new System.Windows.Forms.Padding(4);
            this.tBnota5.MaxLength = 3;
            this.tBnota5.Name = "tBnota5";
            this.tBnota5.Size = new System.Drawing.Size(55, 24);
            this.tBnota5.TabIndex = 19;
            this.tBnota5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBnota5_KeyPress);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(311, 71);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 17);
            this.label14.TabIndex = 18;
            this.label14.Text = "Nota 5";
            // 
            // tBnota4
            // 
            this.tBnota4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBnota4.Location = new System.Drawing.Point(237, 89);
            this.tBnota4.Margin = new System.Windows.Forms.Padding(4);
            this.tBnota4.MaxLength = 3;
            this.tBnota4.Name = "tBnota4";
            this.tBnota4.Size = new System.Drawing.Size(55, 24);
            this.tBnota4.TabIndex = 17;
            this.tBnota4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBnota4_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(177, 94);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 17);
            this.label13.TabIndex = 16;
            this.label13.Text = "Nota 4";
            // 
            // tBnota2
            // 
            this.tBnota2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBnota2.Location = new System.Drawing.Point(100, 89);
            this.tBnota2.Margin = new System.Windows.Forms.Padding(4);
            this.tBnota2.MaxLength = 3;
            this.tBnota2.Name = "tBnota2";
            this.tBnota2.Size = new System.Drawing.Size(55, 24);
            this.tBnota2.TabIndex = 15;
            this.tBnota2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBnota2_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(40, 94);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 17);
            this.label12.TabIndex = 14;
            this.label12.Text = "Nota 2";
            // 
            // tBnota3
            // 
            this.tBnota3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBnota3.Location = new System.Drawing.Point(237, 50);
            this.tBnota3.Margin = new System.Windows.Forms.Padding(4);
            this.tBnota3.MaxLength = 3;
            this.tBnota3.Name = "tBnota3";
            this.tBnota3.Size = new System.Drawing.Size(55, 24);
            this.tBnota3.TabIndex = 13;
            this.tBnota3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBnota3_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(177, 55);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 17);
            this.label11.TabIndex = 12;
            this.label11.Text = "Nota 3";
            // 
            // tBnota1
            // 
            this.tBnota1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tBnota1.Location = new System.Drawing.Point(100, 50);
            this.tBnota1.Margin = new System.Windows.Forms.Padding(4);
            this.tBnota1.MaxLength = 3;
            this.tBnota1.Name = "tBnota1";
            this.tBnota1.Size = new System.Drawing.Size(55, 24);
            this.tBnota1.TabIndex = 11;
            this.tBnota1.TextChanged += new System.EventHandler(this.tBnota1_TextChanged);
            this.tBnota1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tBnota1_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(40, 55);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Nota 1";
            // 
            // BtSalir
            // 
            this.BtSalir.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtSalir.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtSalir.Location = new System.Drawing.Point(519, 518);
            this.BtSalir.Margin = new System.Windows.Forms.Padding(4);
            this.BtSalir.Name = "BtSalir";
            this.BtSalir.Size = new System.Drawing.Size(100, 28);
            this.BtSalir.TabIndex = 22;
            this.BtSalir.Text = "Salir";
            this.BtSalir.UseVisualStyleBackColor = false;
            this.BtSalir.Click += new System.EventHandler(this.button2_Click);
            // 
            // numerocel
            // 
            this.numerocel.ContainerControl = this;
            // 
            // Numerofijo
            // 
            this.Numerofijo.ContainerControl = this;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(399, 10);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(346, 45);
            this.label16.TabIndex = 3;
            this.label16.Text = "CALCULA TU NOTA";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.BackgroundImage = global::Grade_calculator.Properties.Resources.fondo_abstracto_neutro_negro_oscuro_diseno_presentacion_181182_592;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.BtSalir);
            this.Controls.Add(this.grpNotas);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Grade Calculator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpNotas.ResumeLayout(false);
            this.grpNotas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numerocel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Numerofijo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbNamestudent;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cBNcurso;
        private System.Windows.Forms.ComboBox cBPrograma;
        private System.Windows.Forms.TextBox tBCorreo;
        private System.Windows.Forms.TextBox tBFijo;
        private System.Windows.Forms.TextBox tBCelular;
        private System.Windows.Forms.TextBox tBapellido;
        private System.Windows.Forms.TextBox tBnombre;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox grpNotas;
        private System.Windows.Forms.Button btCalcular;
        private System.Windows.Forms.TextBox tBnota5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tBnota4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tBnota2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tBnota3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tBnota1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button BtSalir;
        private System.Windows.Forms.Button btLimpiar;
        private System.Windows.Forms.ErrorProvider numerocel;
        private System.Windows.Forms.ErrorProvider Numerofijo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lbCprograma;
        private System.Windows.Forms.Label lbCredicurso;
        private System.Windows.Forms.Label lbCcurso;
        private System.Windows.Forms.Label label16;
    }
}

