﻿namespace Grade_calculator
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblApellidos = new System.Windows.Forms.Label();
            this.lblCelular = new System.Windows.Forms.Label();
            this.lblFijo = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.btnVolver = new System.Windows.Forms.Button();
            this.lblCreditos = new System.Windows.Forms.Label();
            this.lblPrograma = new System.Windows.Forms.Label();
            this.lblCodPrograma = new System.Windows.Forms.Label();
            this.lblCurso = new System.Windows.Forms.Label();
            this.lblCodCurso = new System.Windows.Forms.Label();
            this.lblNota = new System.Windows.Forms.Label();
            this.lblSituacion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre.ForeColor = System.Drawing.Color.White;
            this.lblNombre.Location = new System.Drawing.Point(28, 24);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(49, 13);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "Nombres";
            // 
            // lblApellidos
            // 
            this.lblApellidos.AutoSize = true;
            this.lblApellidos.BackColor = System.Drawing.Color.Transparent;
            this.lblApellidos.ForeColor = System.Drawing.Color.White;
            this.lblApellidos.Location = new System.Drawing.Point(28, 51);
            this.lblApellidos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblApellidos.Name = "lblApellidos";
            this.lblApellidos.Size = new System.Drawing.Size(53, 13);
            this.lblApellidos.TabIndex = 1;
            this.lblApellidos.Text = "Apeliddos";
            // 
            // lblCelular
            // 
            this.lblCelular.AutoSize = true;
            this.lblCelular.BackColor = System.Drawing.Color.Transparent;
            this.lblCelular.ForeColor = System.Drawing.Color.White;
            this.lblCelular.Location = new System.Drawing.Point(28, 83);
            this.lblCelular.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCelular.Name = "lblCelular";
            this.lblCelular.Size = new System.Drawing.Size(39, 13);
            this.lblCelular.TabIndex = 2;
            this.lblCelular.Text = "Celular";
            // 
            // lblFijo
            // 
            this.lblFijo.AutoSize = true;
            this.lblFijo.BackColor = System.Drawing.Color.Transparent;
            this.lblFijo.ForeColor = System.Drawing.Color.White;
            this.lblFijo.Location = new System.Drawing.Point(28, 114);
            this.lblFijo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblFijo.Name = "lblFijo";
            this.lblFijo.Size = new System.Drawing.Size(23, 13);
            this.lblFijo.TabIndex = 3;
            this.lblFijo.Text = "Fijo";
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.BackColor = System.Drawing.Color.Transparent;
            this.lblCorreo.ForeColor = System.Drawing.Color.White;
            this.lblCorreo.Location = new System.Drawing.Point(28, 148);
            this.lblCorreo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(94, 13);
            this.lblCorreo.TabIndex = 4;
            this.lblCorreo.Text = "Correo Electronico";
            // 
            // btnVolver
            // 
            this.btnVolver.BackColor = System.Drawing.Color.Transparent;
            this.btnVolver.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVolver.ForeColor = System.Drawing.Color.Black;
            this.btnVolver.Location = new System.Drawing.Point(396, 250);
            this.btnVolver.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnVolver.Name = "btnVolver";
            this.btnVolver.Size = new System.Drawing.Size(70, 33);
            this.btnVolver.TabIndex = 5;
            this.btnVolver.Text = "Volver";
            this.btnVolver.UseVisualStyleBackColor = false;
            this.btnVolver.Click += new System.EventHandler(this.btnVolver_Click);
            // 
            // lblCreditos
            // 
            this.lblCreditos.AutoSize = true;
            this.lblCreditos.BackColor = System.Drawing.Color.Transparent;
            this.lblCreditos.ForeColor = System.Drawing.Color.White;
            this.lblCreditos.Location = new System.Drawing.Point(278, 143);
            this.lblCreditos.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCreditos.Name = "lblCreditos";
            this.lblCreditos.Size = new System.Drawing.Size(91, 13);
            this.lblCreditos.TabIndex = 6;
            this.lblCreditos.Text = "Creditos del curso";
            // 
            // lblPrograma
            // 
            this.lblPrograma.AutoSize = true;
            this.lblPrograma.BackColor = System.Drawing.Color.Transparent;
            this.lblPrograma.ForeColor = System.Drawing.Color.White;
            this.lblPrograma.Location = new System.Drawing.Point(278, 24);
            this.lblPrograma.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrograma.Name = "lblPrograma";
            this.lblPrograma.Size = new System.Drawing.Size(52, 13);
            this.lblPrograma.TabIndex = 7;
            this.lblPrograma.Text = "Programa";
            // 
            // lblCodPrograma
            // 
            this.lblCodPrograma.AutoSize = true;
            this.lblCodPrograma.BackColor = System.Drawing.Color.Transparent;
            this.lblCodPrograma.ForeColor = System.Drawing.Color.White;
            this.lblCodPrograma.Location = new System.Drawing.Point(278, 51);
            this.lblCodPrograma.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCodPrograma.Name = "lblCodPrograma";
            this.lblCodPrograma.Size = new System.Drawing.Size(104, 13);
            this.lblCodPrograma.TabIndex = 8;
            this.lblCodPrograma.Text = "Codigo del programa";
            // 
            // lblCurso
            // 
            this.lblCurso.AutoSize = true;
            this.lblCurso.BackColor = System.Drawing.Color.Transparent;
            this.lblCurso.ForeColor = System.Drawing.Color.White;
            this.lblCurso.Location = new System.Drawing.Point(278, 85);
            this.lblCurso.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCurso.Name = "lblCurso";
            this.lblCurso.Size = new System.Drawing.Size(34, 13);
            this.lblCurso.TabIndex = 9;
            this.lblCurso.Text = "Curso";
            // 
            // lblCodCurso
            // 
            this.lblCodCurso.AutoSize = true;
            this.lblCodCurso.BackColor = System.Drawing.Color.Transparent;
            this.lblCodCurso.ForeColor = System.Drawing.Color.White;
            this.lblCodCurso.Location = new System.Drawing.Point(278, 113);
            this.lblCodCurso.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCodCurso.Name = "lblCodCurso";
            this.lblCodCurso.Size = new System.Drawing.Size(86, 13);
            this.lblCodCurso.TabIndex = 10;
            this.lblCodCurso.Text = "Codigo del curso";
            // 
            // lblNota
            // 
            this.lblNota.AutoSize = true;
            this.lblNota.BackColor = System.Drawing.Color.Transparent;
            this.lblNota.ForeColor = System.Drawing.Color.White;
            this.lblNota.Location = new System.Drawing.Point(87, 198);
            this.lblNota.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNota.Name = "lblNota";
            this.lblNota.Size = new System.Drawing.Size(13, 13);
            this.lblNota.TabIndex = 11;
            this.lblNota.Text = "0";
            // 
            // lblSituacion
            // 
            this.lblSituacion.AutoSize = true;
            this.lblSituacion.BackColor = System.Drawing.Color.Transparent;
            this.lblSituacion.ForeColor = System.Drawing.Color.White;
            this.lblSituacion.Location = new System.Drawing.Point(277, 198);
            this.lblSituacion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSituacion.Name = "lblSituacion";
            this.lblSituacion.Size = new System.Drawing.Size(51, 13);
            this.lblSituacion.TabIndex = 12;
            this.lblSituacion.Text = "Situacion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(32, 198);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Promedio:";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Grade_calculator.Properties.Resources.fondo_abstracto_neutro_negro_oscuro_diseno_presentacion_181182_592;
            this.ClientSize = new System.Drawing.Size(487, 294);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblSituacion);
            this.Controls.Add(this.lblNota);
            this.Controls.Add(this.lblCodCurso);
            this.Controls.Add(this.lblCurso);
            this.Controls.Add(this.lblCodPrograma);
            this.Controls.Add(this.lblPrograma);
            this.Controls.Add(this.lblCreditos);
            this.Controls.Add(this.btnVolver);
            this.Controls.Add(this.lblCorreo);
            this.Controls.Add(this.lblFijo);
            this.Controls.Add(this.lblCelular);
            this.Controls.Add(this.lblApellidos);
            this.Controls.Add(this.lblNombre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.Label lblNombre;
        public System.Windows.Forms.Label lblApellidos;
        public System.Windows.Forms.Label lblCelular;
        public System.Windows.Forms.Label lblFijo;
        public System.Windows.Forms.Label lblCorreo;
        public System.Windows.Forms.Button btnVolver;
        public System.Windows.Forms.Label lblCreditos;
        public System.Windows.Forms.Label lblPrograma;
        public System.Windows.Forms.Label lblCodPrograma;
        public System.Windows.Forms.Label lblCurso;
        public System.Windows.Forms.Label lblCodCurso;
        public System.Windows.Forms.Label lblNota;
        public System.Windows.Forms.Label lblSituacion;
        private System.Windows.Forms.Label label1;
    }
}