﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Grade_calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btLimpiar_Click(object sender, EventArgs e)
        {
            tBnombre.Text = "";
            tBapellido.Text = "";
            tBCelular.Text = "";
            tBFijo.Text = "";
            tBCorreo.Text = "";           
            cBPrograma.SelectedIndex = 0;
            cBNcurso.SelectedIndex = 0;
            tBnota1.Text = "";
            tBnota2.Text = "";
            tBnota3.Text = "";
            tBnota4.Text = "";
            tBnota5.Text = "";
            lbCprograma.Text = "";
            lbCredicurso.Text = "";
            lbCcurso.Text = "";
        }

        private void tBnota1_TextChanged(object sender, EventArgs e)
        {

        }

    
        private void tBnombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            validaciones.SoloLetras(e);
            activarnotas();
        }

        private void tBapellido_KeyPress(object sender, KeyPressEventArgs e)
        {
            validaciones.SoloLetras(e);
            activarnotas();
        }

        private void tBCelular_KeyPress(object sender, KeyPressEventArgs e)
        {
            validaciones.SoloNumeros(e);
            numerocel.Clear();
            if (tBCelular.Text.IndexOf("3") == 0)
            {
                numerocel.Clear();
            }
            else
            {

                numerocel.SetError(tBCelular, "Intentalo Nuevamente, El numero Celular empieza por 3");
            }
            activarnotas();
        }

        private void tBFijo_KeyPress(object sender, KeyPressEventArgs e)
        {
            validaciones.SoloNumeros(e);
            Numerofijo.Clear();
            if (tBFijo.Text.IndexOf("2") == 0 || tBFijo.Text.IndexOf("3") == 0 || tBFijo.Text.IndexOf("4") == 0 || tBFijo.Text.IndexOf("5") == 0)
            {
                Numerofijo.Clear();
            }
            else
            {

                Numerofijo.SetError(tBFijo, "Intentalo Nuevamente, El numero de telefono empieza por (2,3,4,5)");
            }
            activarnotas();

        }

        private void cBPrograma_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBPrograma.SelectedIndex == 0)
            {
                lbCprograma.Text = "";
            }
            if (cBPrograma.SelectedIndex == 1)
            {
                lbCprograma.Text = "SNIES 102695";
            }
            if (cBPrograma.SelectedIndex == 2)
            {
                lbCprograma.Text = "SNIES 2076";
            }
            if (cBPrograma.SelectedIndex == 3)
            {
                lbCprograma.Text = "SNIES 107279";
            }
            if (cBPrograma.SelectedIndex == 4)
            {
                lbCprograma.Text = "SNIES 106410";
            }
            if (cBPrograma.SelectedIndex == 5)
            {
                lbCprograma.Text = "SNIES 108434";
            }
            if (cBPrograma.SelectedIndex == 6)
            {
                lbCprograma.Text = "SNIES 107676";
            }
            activarnotas();
        }

        private void cBNcurso_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cBNcurso.SelectedIndex == 0)
            {
                lbCcurso.Text = "";
                lbCredicurso.Text = "";
            }
            if (cBNcurso.SelectedIndex == 1)
            {
                lbCcurso.Text = " ET0182 ";
                lbCredicurso.Text = "4 creditos";
            }
            if (cBNcurso.SelectedIndex == 2)
            {
                lbCcurso.Text = " ET0191 ";
                lbCredicurso.Text = "2 creditos";
            }
            if (cBNcurso.SelectedIndex == 3)
            {
                lbCcurso.Text = " ET0056 ";
                lbCredicurso.Text = "4 creditos";
            }
            if (cBNcurso.SelectedIndex == 4)
            {
                lbCcurso.Text = " ET0193 ";
                lbCredicurso.Text = "4 creditos";
            }
            if (cBNcurso.SelectedIndex == 5)
            {
                lbCcurso.Text = " ET0194 ";
                lbCredicurso.Text = "3 creditos";
            }
            if (cBNcurso.SelectedIndex == 6)
            {
                lbCcurso.Text = " FB0084 ";
                lbCredicurso.Text = "1 credito";
            }
            activarnotas();
        }

        private void tBnota1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void tBnota2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void tBnota3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void tBnota4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void tBnota5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != ','))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        void activarnotas()
        {
            if(tBnombre.Text!="" && tBapellido.Text!="" && tBCelular.Text!="" && tBFijo.Text!="" && tBCorreo.Text!="" && cBPrograma.Text!="" && cBNcurso.Text != "")
            {
                grpNotas.Enabled = true;
            }
            else
            {
                grpNotas.Enabled = false;
            }

        }
  

        private void tBCorreo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btCalcular_Click(object sender, EventArgs e)
        {
            Form2 Formulario2 = new Form2();
            if (tBnombre.Text == "" || tBapellido.Text == "" || tBCelular.Text == "" || tBFijo.Text == "" || tBCorreo.Text == "" || cBPrograma.SelectedIndex == 0 || cBNcurso.SelectedIndex == 0)
            {

                MessageBox.Show("Por favor Ingresa los Datos correspodientes");
            }
            else
            {
                if (tBCelular.Text.Trim().Length == 10)
                {
                    if (tBCelular.Text.IndexOf("3") == 0)
                    {
                        if (tBFijo.Text.Trim().Length == 7)
                        {
                            if (tBFijo.Text.IndexOf("2") == 0 || tBFijo.Text.IndexOf("3") == 0 || tBFijo.Text.IndexOf("4") == 0 || tBFijo.Text.IndexOf("5") == 0)
                            {

                                if (tBnota1.Text == "" || tBnota2.Text == "" || tBnota3.Text == "" || tBnota4.Text == "" || tBnota5.Text == "")
                                {
                                    MessageBox.Show("Por favor completar todos los campos de la nota, para poder calcular su nota. Gracias");
                                }
                                else
                                {
                                    double nota1, nota2, nota3, nota4, nota5, Promedio;
                                   
                                    nota1 = double.Parse(tBnota1.Text);
                                    nota2 = double.Parse(tBnota2.Text);
                                    nota3 = double.Parse(tBnota3.Text);
                                    nota4 = double.Parse(tBnota4.Text);
                                    nota5 = double.Parse(tBnota5.Text);                              
                                    if (nota1 <= 5 && nota2 <= 5 && nota3 <= 5 && nota4 <= 5 && nota5 <= 5)
                                    {
                                        nota1 = (nota1 * 0.20);
                                        nota2 = (nota2 * 0.25);
                                        nota3 = (nota3 * 0.25);
                                        nota4 = (nota4 * 0.15);
                                        nota5 = (nota5 * 0.15);

                                        Promedio = (nota1 + nota2 + nota3 + nota4 + nota5);                                        
                                        Formulario2.lblNota.Text = Promedio.ToString();                                      


                                        if (Promedio < 2.5)
                                        {
                                            Formulario2.lblSituacion.Text = "Rendimiento Insuficiente";
                                            Formulario2.lblNota.Text = Promedio.ToString();
                                        }
                                        if (Promedio >= 2.5 && Promedio < 3)
                                            {
                                                Formulario2.lblSituacion.Text = "Situacion Especial";
                                                Formulario2.lblNota.Text = Promedio.ToString();
                                            }
                                        if (Promedio >= 3 && Promedio < 4)
                                        {
                                                Formulario2.lblSituacion.Text = "Situacion Normal";
                                                Formulario2.lblNota.Text = Promedio.ToString();
                                        }
                                        if (Promedio >= 4 && Promedio < 4.5)
                                            {
                                                Formulario2.lblSituacion.Text = "Situacion Sobresaliente";
                                                Formulario2.lblNota.Text = Promedio.ToString();
                                            }
                                        if (Promedio >= 4.5 && Promedio <= 5)
                                            {
                                                Formulario2.lblSituacion.Text = "Situacion Excelente";
                                                Formulario2.lblNota.Text = Promedio.ToString();
                                            }
                                        Formulario2.lblNombre.Text = tBnombre.Text;
                                        Formulario2.lblApellidos.Text = tBapellido.Text;
                                        Formulario2.lblCelular.Text = tBCelular.Text;
                                        Formulario2.lblFijo.Text = tBFijo.Text;
                                        Formulario2.lblCorreo.Text = tBCorreo.Text + "@pascualbravo.edu.co";
                                        Formulario2.lblPrograma.Text = cBPrograma.Text;
                                        Formulario2.lblCodPrograma.Text = lbCprograma.Text;
                                        Formulario2.lblCurso.Text = cBNcurso.Text;
                                        Formulario2.lblCodCurso.Text = lbCcurso.Text;
                                        Formulario2.lblCreditos.Text = lbCredicurso.Text;
                                        Formulario2.Show();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Notas de 0 a 5 con comas");
                                    }
                                }

                            }
                            else
                            {
                                MessageBox.Show("Solo telefonos que empiezan 2, 3, 4, 5");
                                tBFijo.Text = "";
                            }

                        }
                        else
                        {
                            MessageBox.Show("Por favor ingresar solo numeros fijos que tienen 7 digitos");
                            tBFijo.Text = "";
                        }

                    }
                    else
                    {
                        MessageBox.Show("Por favor ingresar solo numeros celulares que empiezan por 3 ");
                        tBCelular.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Cualquier celular tiene 10 digitos");
                    tBCelular.Text = "";
                }                                            
                
            }          

        }
        private void tBnombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
